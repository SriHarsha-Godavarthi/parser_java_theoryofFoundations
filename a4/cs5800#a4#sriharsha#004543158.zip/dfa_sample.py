# DFA Minimization using table filling algoritm merge equivalence states
def minimize_dfa(dfa):
    states = dfa['states']
    accept_states = dfa['accept_states']
    transitions = dfa['transitions']
    
    # Step 1: Initialize the table
    table = {}
    for i in range(len(states)):
        for j in range(i+1, len(states)):
            if (states[i] in accept_states) or (states[j] in accept_states):
                table[(states[i], states[j])] = True
                
    # Step 2: Mark distinguishable states
    changed = True
    while changed:
        changed = False
        for i in range(len(states)):
            for j in range(i+1, len(states)):
                if (states[i], states[j]) not in table:
                    for a in dfa['alphabet']:
                        delta_i = transitions[(states[i], a)]
                        delta_j = transitions[(states[j], a)]
                        if delta_i != delta_j:
                           if (tuple(sorted((delta_i, delta_j))) in table) or (tuple(sorted((delta_j, delta_i))) in table):
                                table[(states[i], states[j])] = True
                                changed = True
                                break
    # Step 3: Merge equivalent states
    new_states = {}
    for i in range(len(states)):
        for j in range(i+1, len(states)):
            if (states[i], states[j]) not in table:
                if states[i] not in new_states:
                    new_states[states[i]] = f"{states[i]}/{states[j]}"
                new_states[states[j]] = new_states[states[i]]
                
    minimized_dfa = {'states': list(set(new_states.values())), 'alphabet': dfa['alphabet'], 'transitions': {}, 'start_state': new_states.get(dfa['start_state'], dfa['start_state']), 'accept_states': set()}
    for (state, a), next_state in transitions.items():
        new_state = new_states.get(state, state)
        new_next_state = new_states.get(next_state, next_state)
        minimized_dfa['transitions'][(new_state, a)] = new_next_state
        if state in accept_states:
            minimized_dfa['accept_states'].add(new_state)
    data=(',').join(minimized_dfa['states'])
    for state in dfa['states']:
        if data.__contains__(state):
            pass
        else:
            minimized_dfa['states'].append(state)
    return minimized_dfa

# DFA Simulator for computation on input staring
def simulate_dfa(dfa, string):
    current_state = dfa['start_state']
    i=0
    print(f"-[{current_state},{string}]")
    for character in string:
        new_current_state = dfa['transitions'].get((current_state, character), None)
        # print(f"{current_state}->{character}:{new_current_state}")
        i+=1
        new_string=string[i:len(string)]
        if new_string=='':
            print(f"-[{new_current_state},λ]")
        else:    
          print(f"-[{new_current_state},{new_string}]")
        
        if new_current_state is None:
            return f"Computation: Reject"
        current_state=new_current_state
    if current_state in dfa['accept_states']:
        return f"Computation: Accept"
    else:
        return f"Computation: Reject"

# Example DFA M'

files=['dfa_input.txt','dfa_input2.txt']
for file in files:
    dfa_example={
        'states': [],
        'alphabet':[],
        'transitions':{},
        'start_state':'',
        'accept_states': set()
    }
    with open(file, 'r') as file:
            lines = file.readlines()
            for line in lines:
                # print(line)
                if line.__contains__('\n'):
                 line=line[0:len(line)-1]
                rule=line.split(':')
                state_processing=''
                if line.__contains__('-->'):
                    start_state=rule[0]
                    dfa_example['start_state']=start_state[3:len(start_state)]
                    # print("start_state",dfa_example['start_state'])
                    dfa_example['states'].append(start_state[3:len(start_state)])
                    state_processing=start_state[3:len(start_state)]
                elif line.__contains__('*'):
                    end_state=rule[0]
                    # print(type(dfa_example['accept_states']))
                    dfa_example['accept_states'].add(end_state[1:len(end_state)])
                    # print("acceptence state",dfa_example['accept_states'])
                    dfa_example['states'].append(end_state[1:len(end_state)])
                    state_processing=end_state[1:len(end_state)]
                else:
                    current_state=rule[0].strip()
                    dfa_example['states'].append(current_state)
                    state_processing=current_state
                rule=rule[1].split(',')
                for production in rule:
                    input_symbol=production.split('->')
                    if len(dfa_example['alphabet'])!=len(rule):
                        dfa_example['alphabet'].append(input_symbol[0].strip())
                    dfa_example['transitions'][(state_processing),(input_symbol[0].strip())]=input_symbol[1].strip()
                
                
    input_string = input('Enter computation String:')
    dfa_computation_m1=simulate_dfa(dfa_example, input_string)
    print('Computation result:',dfa_computation_m1)
    # Minimize DFA M'
    minimized_dfa = minimize_dfa(dfa_example)

    # Simulate DFA on a given string

    result = simulate_dfa(minimized_dfa, input_string)
    print("Minimized DFA:", minimized_dfa)
    print("Simulation Result:", result)
